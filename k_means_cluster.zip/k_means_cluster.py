import pandas as pd
import sys
import numpy as np


# Command-line arguments
data_file = sys.argv[1]
k = int(sys.argv[2])
iterations = int(sys.argv[3])

# Read data from file and dropping last column
data = np.loadtxt(data_file)
# Remove the last column from the array
data = data[:, :-1]

# Save the modified array back to the file (overwriting the original data)
np.savetxt(data_file, data)

df = pd.read_csv(data_file)
df.drop(df.columns[-1], axis="columns", inplace=True)

#data = df.values

# Initialize clusters randomly
num_samples, num_features = data.shape
clusters = np.random.randint(low=0, high=k, size=num_samples)

# Compute initial means of clusters
means = np.zeros((k, num_features))
for i in range(k):
    means[i] = np.mean(data[clusters == i], axis=0)


# Compute initialization error
error = 0
for i in range(num_samples):
    distance = np.sqrt(np.sum(np.square(data[i] - means[clusters[i]])))
    error += np.linalg.norm(data[i] - means[clusters[i]])
print("After initialization: error = %.4f" % error)

# K-means clustering
for it in range(iterations):
    # Assigning each sample to the nearest cluster
    for i in range(num_samples):
        
        distances = [np.linalg.norm(data[i] - means[j]) for j in range(k)]
        clusters[i] = np.argmin(distances)

    # Updating the cluster means
    for i in range(k):
        means[i] = np.mean(data[clusters == i], axis=0)

    # Compute error through euclidean distance
    error = 0
    for i in range(num_samples):
        distance = np.sqrt(np.sum(np.square(data[i] - means[clusters[i]])))
        error += np.linalg.norm(data[i] - means[clusters[i]])
        
    print("After iteration %d: error = %.4f" % (it + 1, error))

